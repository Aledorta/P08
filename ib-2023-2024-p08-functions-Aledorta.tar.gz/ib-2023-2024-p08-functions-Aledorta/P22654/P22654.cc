#include <iostream>

// Función para descomponer el tiempo en horas, minutos y segundos
void decompose(int n, int& h, int& m, int& s) {
	h = n/3600;
	m = (n/60)%60;
	s = n%60;
}

// Función principal
int main () {
	int n, h, m, s;
	while (std::cin >> n) {
		decompose(n, h, m, s);
		std::cout << h << " " << m << " " << s << std::endl;
	}
	return 0;
}