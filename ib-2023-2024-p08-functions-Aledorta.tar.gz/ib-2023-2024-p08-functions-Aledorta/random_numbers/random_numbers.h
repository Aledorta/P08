/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Genera un número random entre dos números, siendo n1 < n2
 * @see Define las funciones que se utilizaran en el main.cc
 */

#include <iostream>
#include <ctime> // Incluye la biblioteca para obtener una semilla aleatoria
#include <cstdlib> // Incluye la biblioteca de funciones de números aleatorios

/**
 * @brief Muestra información de uso y ayuda del programa.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
void Usage(int argc, char *argv[]);

/**
 * @brief Genera un número aleatorio dentro de un rango dado.
 * 
 * @param numero_1 Límite inferior del rango.
 * @param numero_2 Límite superior del rango.
 * @return Número aleatorio dentro del rango [numero_1, numero_2].
 */
int Random_number(int numero_1, int numero_2);