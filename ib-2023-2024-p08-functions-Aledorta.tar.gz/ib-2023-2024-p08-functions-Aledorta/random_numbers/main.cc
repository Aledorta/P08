/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Genera un número random entre dos números, siendo n1 < n2
 * @see Programa principal
 */

#include <iostream>

#include "random_numbers.h"

/**
 * @brief Función principal que genera un número aleatorio dentro de un rango.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
int main(int argc, char *argv[]) {
  // Muestra información de uso y ayuda si se proporciona el argumento "--help".
  Usage(argc, argv);
  // Convierte y almacena los argumentos proporcionados en variables.
  std::string numero = argv[1];
  int numero_1 = std::stoi(numero);
  numero = argv[2];
  int numero_2 = std::stoi(numero);
  // Verifica si el primer número es menor que el segundo y genera un número aleatorio.
  if (numero_1 < numero_2) {
    std::cout << Random_number(numero_1, numero_2) << std::endl;
  } else {
     std::cout << "Error. Pruebe " << argv[0] << " --help para más información" << std::endl;
  }
  return 0;
}