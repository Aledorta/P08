/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Cambia las minúsculas por mayúsculas en una cadena y viceversa
 * @see contiene las fucniones de random_numbers.h
 */

#include "random_numbers.h"

void Usage(int argc, char *argv[]) {
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Cambia las minúsculas por mayúsculas en una cadena y viceversa";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  // Verifica si se proporciona la cantidad correcta de argumentos (3 en total, incluido el nombre del programa).
  if (argc != 3) {
    std::cout << argv[0] << ": Falta un número natural como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

int Random_number(int numero_1, int numero_2) {
  // Establece la semilla para la generación de números aleatorios
  std::srand(static_cast<unsigned int>(std::time(nullptr)));
  int random_number = numero_1 + std::rand() % (numero_2 - numero_1 + 1);
  return random_number;
}

