/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Calcula el área de un triángulo
 * @see Programa principal
 */

#include <iostream>

#include "triangle_area.h"

/**
 * @brief Función principal que calcula el área de un triángulo.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
int main(int argc, char *argv[]) {
  // Muestra información de uso y ayuda si se proporciona el argumento "--help".
  Usage(argc, argv);
  // Convierte y almacena los argumentos proporcionados en variables.
  std::string numero = argv[1];
  double lado1 = std::stod(numero);
  numero = argv[2];
  double lado2 = std::stod(numero);
  numero = argv[3];
  double lado3 = std::stod(numero);
  // Verifica la validez del triángulo y calcula su área.
  IsValidTriangle(lado1, lado2, lado3);
  std::cout << CalculateArea(lado1, lado2, lado3) << std::endl;
  return 0;
}