/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Calcula el área de un triángulo
 * @see contiene las fucniones de random_numbers.h
 */

#include "triangle_area.h"

void Usage(int argc, char *argv[]) {
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Calcula el área de un triángulo";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  
  // Verifica si se proporciona la cantidad correcta de argumentos (4 en total, incluido el nombre del programa).
  if (argc != 4) {
    std::cout << argv[0] << ": Falta un número natural como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

void IsValidTriangle(double lado1, double lado2, double lado3) {
  // Si un lado es negativo sale del programa
  if (lado1 <= 0 | lado2 <= 0 | lado3 <= 0) {
    std::cout << "Triángulo no valido" << std::endl;
    exit(EXIT_SUCCESS);
  }

  // Todos los triángulos cumplen la regla de que cada lado tiene que ser menor que la suma de sus otros lados
  if (lado1 > (lado2 + lado3) | lado2 > (lado1 + lado3) | lado3 > (lado1 + lado2)) {
    std::cout << "Triángulo no valido" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

double CalculateArea(double lado1, double lado2, double lado3) {
  double perimetro, area;
  perimetro = (lado1 + lado2 + lado3) / 2.0;
  area = sqrt(perimetro * (perimetro - lado1) * (perimetro - lado2) * (perimetro - lado3));
  return area;
}