/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Calcula el área de un triángulo
 * @see Define las funciones que se utilizaran en el main.cc
 */

#include <iostream>
#include <cmath>

/**
 * @brief Muestra información de uso y ayuda del programa.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
void Usage(int argc, char *argv[]);

/**
 * @brief Verifica la validez de un triángulo dado sus tres lados.
 * 
 * @param lado1 Longitud del primer lado del triángulo.
 * @param lado2 Longitud del segundo lado del triángulo.
 * @param lado3 Longitud del tercer lado del triángulo.
 */
void IsValidTriangle(double lado1, double lado2, double lado3);

/**
 * @brief Calcula el área de un triángulo dado sus tres lados utilizando la fórmula de Herón.
 * 
 * @param lado1 Longitud del primer lado del triángulo.
 * @param lado2 Longitud del segundo lado del triángulo.
 * @param lado3 Longitud del tercer lado del triángulo.
 * @return El área del triángulo.
 */
double CalculateArea(double lado1, double lado2, double lado3);