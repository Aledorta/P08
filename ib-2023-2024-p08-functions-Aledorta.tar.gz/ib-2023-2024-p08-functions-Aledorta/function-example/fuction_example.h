/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Da la solución a la funcion f(a¡x, y, t) ) ((sqrt(2 * t -4)) / x^2 - y^2)
 * @see Define las funciones que se utilizaran en el main.cc
 */

#include <iostream>
#include <math.h>

/**
 * @brief Función que muestra el uso del programa y proporciona información de ayuda.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
void Usage(int argc, char *argv[]);

/**
 * @brief Función que calcula el resultado de la función f(a, x, y, t).
 * 
 * @param numero_x Valor de 'x' en la función.
 * @param numero_y Valor de 'y' en la función.
 * @param numero_t Valor de 't' en la función.
 * @return Resultado de la función f(a, x, y, t).
 */
double Funcion(double numero_x, double numero_y, double numero_t);