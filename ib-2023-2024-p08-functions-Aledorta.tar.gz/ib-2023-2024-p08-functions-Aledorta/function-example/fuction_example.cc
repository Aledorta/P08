/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Da la solución a la funcion f(a¡x, y, t) ) ((sqrt(2 * t -4)) / x^2 - y^2)
 * @see contiene las fucniones de function_example.h
 */

#include "fuction_example.h"

void Usage(int argc, char *argv[]) {
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Da la solución a la funcion f(a¡x, y, t) ) ((sqrt(2 * t -4)) / x^2 - y^2)";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  // Verifica si se proporcionan los argumentos requeridos (deben ser 4, incluido el nombre del programa).
  if (argc != 4) {
    std::cout << argv[0] << ": Falta un número natural como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

double Funcion(double numero_x, double numero_y, double numero_t) {
  double numerador, denominador, resultado;
  // Calcula el numerador y el denominador de la función.
  numerador = sqrt((2 * numero_t) - 4);
  denominador = (numero_x * numero_x) - (numero_y * numero_y);
  // Calcula el resultado de la función y lo devuelve
  resultado = numerador / denominador;
  return resultado;
}