/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Da la solución a la funcion f(a¡x, y, t) ) ((sqrt(2 * t -4)) / x^2 - y^2)
 * @see Programa principal
 */

#include <iostream>

#include "fuction_example.h"

/**
 * @brief Función principal que realiza el cálculo de la función f(a, x, y, t).
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 * @return 0 si la ejecución es exitosa.
 */
int main(int argc, char *argv[]) {
  // Muestra información de uso y ayuda si se proporciona el argumento "--help"
  Usage(argc, argv);
  // Convierte y almacena los argumentos proporcionados en variables.
  std::string numero = argv[1];
  const double numero_x = stoi(numero);
  numero = argv[2];
  const double numero_y = stoi(numero);
  numero = argv[3];
  const double numero_t = stoi(numero);
  // Calcula y muestra el resultado de la función f(a, x, y, t).
  std::cout << Funcion(numero_x, numero_y, numero_t) << std::endl;
  return 0;
}