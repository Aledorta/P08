/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Cambia las minúsculas por mayúsculas en una cadena y viceversa
 * @see Programa principal
 */

#include <iostream>

#include "change_case.h"

/**
 * @brief Función principal que cambia el caso de una cadena y muestra el resultado.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 * @return 0 si la ejecución es exitosa.
 */
int main(int argc, char *argv[]) {
  // Muestra información de uso y ayuda si se proporciona el argumento "--help".
  Usage(argc, argv);
  // Obtiene la cadena proporcionada como argumento de línea de comandos.
  std::string cadena = argv[1];
  // Cambia el caso de la cadena y muestra el resultado.
  std::cout << Cambiar(cadena) << std::endl;
  return 0;
}