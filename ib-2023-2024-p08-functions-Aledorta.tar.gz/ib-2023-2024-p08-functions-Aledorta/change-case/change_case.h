/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 09 Nov 2023
 * @brief Cambia las minúsculas por mayúsculas en una cadena y viceversa
 * @see Define las funciones que se utilizaran en el main.cc
 */
#include <iostream>

/**
 * @brief Función que muestra el uso del programa y proporciona información de ayuda.
 * 
 * @param argc Cantidad de argumentos de línea de comandos.
 * @param argv Vector de argumentos de línea de comandos.
 */
void Usage(int argc, char *argv[]);

/**
 * @brief Función que cambia el caso de una cadena de texto.
 * 
 * @param cadena La cadena de texto que se desea modificar.
 * @return La cadena con el caso de sus caracteres cambiado (mayúsculas a minúsculas y viceversa).
 */
std::string Cambiar(std::string cadena);