#include <iostream>

// Función que verifica si un año es bisiesto
bool bisiesto (int n) {
  if (n%100==0) {
    if (n%400==0) return 1;
      else {
       return 0; 
      }
  } else if (n%4==0) {
    return 1;
  } else {
    return 0;
  }
}

// Función que verifica si una fecha es válida
bool is_valid_date(int d, int m, int y) {
  if (d < 1 or d > 31) return false;
  if (m < 1 or m > 12) return false;
  if (m==2) {
    if (d > 29) {
      return false;
    }
    if (d == 29 and !bisiesto(y)) {
      return false;
    } 
      return true;
  }
  return !(d == 31 and (m==4 or m==6 or m==9 or m==11)); 
}

// Función principal
int main () {
	int d,m,y;
  while (std::cin >> d) {
    std::cin >> m >> y;
    if (is_valid_date(d,m,y)) {
      std::cout << "true" << std::endl;
    } else {
      std::cout << "false" << std::endl;
    }
  }
}