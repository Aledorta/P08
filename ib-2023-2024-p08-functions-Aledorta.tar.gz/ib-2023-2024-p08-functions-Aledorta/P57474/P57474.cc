#include <iostream>

// Función para calcular el factorial de un número entero positivo
int factorial(int n) {
  int fact = 1;
	for (int i = 1; i <= n; ++i) {
		fact *= i;
	}
	return fact;
}

// Función principal
int main () {
	int n;
	while (std::cin >> n) {	
		std::cout << factorial(n) << std::endl;
	}
	return 0;
}